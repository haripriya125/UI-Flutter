import 'dart:io';
void main() {
int ? a = 10;
int ? b =20;
print('the values of a , b is: ${a+b}');
}
